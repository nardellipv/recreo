@extends('layouts.main') 
@section('content')
    @include('layouts.dashboard.help')    
@endsection