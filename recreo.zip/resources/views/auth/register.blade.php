@extends('layouts.app') 
@section('content')

    @extends('layouts.register.register_user')

@endsection