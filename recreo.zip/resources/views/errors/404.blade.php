@extends('errors::layout')

@section('title', '404')
@section('message', 'Pagina no encontrada')