@extends('layouts.main') 
@section('content')
    @include('layouts.dashboard.cards') 
    @include('layouts.dashboard.documentation') 
    @include('layouts.dashboard.help') 
 @endsection