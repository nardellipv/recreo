<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
        <p class="alert alert-info"><?php echo Session::get('message'); ?></p>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
    <?php endif; ?>
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="header">
                    <h2>
                        Subir el exámen modelo en formato PDF
                    </h2>
                </div>
                <div class="body">
                    <?php echo Form::open(['method' => 'POST','route' => ['uploadFile'], 'style'=>'display:inline', 'enctype' => 'multipart/form-data']); ?>

                    <?php echo e(csrf_field()); ?>

                    <div class="form-line">
                        <input name="file" type="file" id="file">
                    </div>
                    <br/>
                    <button type="submit" class="btn btn-primary waves-effect">Subir Exámen</button>
                    <?php echo Form::Close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>