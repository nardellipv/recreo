 
<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <?php if(Session::has('message')): ?>
        <p class="alert alert-info"><?php echo Session::get('message'); ?></p>
        <?php endif; ?>
        <div class="card">
            <div class="header">
                <h2>
                    Listado de alumnos aprobados
                </h2>
            </div>
            <div class="body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>email</th>
                                <th>password</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->lastname); ?> </td>
                                <td><?php echo e($user->email); ?> </td>
                                <td><button type="button" class="btn bg-purple waves-effect waves-light" 
                                    data-toggle="modal" data-target="#userEditModal-<?php echo e($user->id); ?>">Editar</button></td>
                            </tr>
                            <?php echo $__env->make('admin.modaledit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>