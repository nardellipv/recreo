 
<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <?php if(Session::has('message')): ?>
        <p class="alert alert-info"><?php echo Session::get('message'); ?></p>
        <?php endif; ?>
        <div class="card">
            <div class="header">
                <h2>
                    Listado de alumnos
                    <p class="header-dropdown">
                        <a href="<?php echo e(url('addstudent/student')); ?>" class="btn bg-indigo waves-effect">agregar nuevo alumno</a>
                    </p>
                </h2>
            </div>
    
            <div class="body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Primer Exámen</th>
                                <th>Segundo Exámen</th>
                                <th>Total</th>
                                <th width="200">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($student->name .' '. $student->lastname); ?></td>
                                <td><input type="text" class="form-control" name="name" value="<?php echo e($student->first_note); ?>"  /></td>
                                <td><input type="text" class="form-control" name="name" value="<?php echo e($student->second_note); ?>"  /></td>
                                <td><?php echo e($student->total_note); ?> </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button type="submit" class="btn bg-purple waves-effect waves-light">Guardar</button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>