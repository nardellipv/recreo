<?php $__env->startSection('title', '403'); ?>
<?php $__env->startSection('message', 'Acceso no autorizado'); ?>
<?php echo $__env->make('errors::layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>