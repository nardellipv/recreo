 
<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <?php if(Session::has('message')): ?>
        <p class="alert alert-info"><?php echo Session::get('message'); ?></p>
        <?php endif; ?>
        <div class="card">
            <div class="header">
                <h2>
                    Listado de alumnos
                    <p class="header-dropdown">
                        <a href="<?php echo e(url('addstudent/students')); ?>" class="btn bg-indigo waves-effect">agregar nuevo alumno</a>
                    </p>
                </h2>
            </div>
            <div class="body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th width="35">Edad</th>
                                <th width="35">Nivel</th>
                                <th width="35">Año Cursado</th>
                                <th width="35">1ra Nota</th>
                                <th width="35">2da Nota</th>
                                <th width="35">Total</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($student->name); ?></td>
                                <td><?php echo e($student->lastname); ?> </td>
                                <td><?php echo e(Date::parse($student->birth_date)->age); ?> </td>
                                <td><?php echo e($student->level); ?></td>
                                <td><?php echo e($student->classroom); ?></td>
                                <td><?php echo e($student->first_note); ?></td>
                                <?php if($student->level == 2): ?>
                                <td><?php echo e($student->second_note); ?></td>
                                <?php else: ?>
                                <td style="background-color:red">N/A</td>
                                <?php endif; ?>
                                <td><?php echo e($student->total_note); ?></td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="" class="btn bg-purple waves-effect waves-light" data-toggle="modal" data-target="#studentModal-<?php echo e($student->id); ?>">Ver</a>
                                        <button type="button" class="btn bg-purple waves-effect waves-light" data-toggle="modal" data-target="#studentEditModal-<?php echo e($student->id); ?>">Editar</button>
                                        <button type="button" class="btn bg-purple waves-effect waves-light" data-toggle="modal" data-target="#studentAddNoteModal-<?php echo e($student->id); ?>" disabled>Agregar Notas</button>
                                        <button type="button" class="btn bg-red waves-effect waves-light" data-toggle="modal" data-target="#deleteStudentModal-<?php echo e($student->id); ?>">Borrar</button>
                                    </div>
                                </td>
                            </tr>
    <?php echo $__env->make('students.modalstudents.profilestudent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('students.modalstudents.addnote', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('students.modalstudents.deletestudent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('students.modalstudents.editstudent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>