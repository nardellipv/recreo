<div class="modal fade in" id="userEditModal-<?php echo e($user->id); ?>" tabindex="-1" role="dialog">
        <?php echo Form::model($user, ['method' => 'PATCH','route' => ['admin.update', $user->id]]); ?> 
        <?php echo e(csrf_field()); ?>

        <div class="modal-dialog" role="document">
            <div class="modal-content modal-col-indigo">
                <div class="modal-header">
                    <h4 class="modal-title" id="defaultModalLabel">Datos del alumno <?php echo e($user->name); ?></h4>
                </div>
                <div class="modal-body">
                    <ul class="dashboard-stat-list">
                        <li>
                            Nombre
                            <span class="pull-right">                                
                                        <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" required />
                                    </span>
                        </li>
                        <li>
                            Apellido
                            <span class="pull-right">
                                <input type="text" class="form-control" name="lastname" value="<?php echo e($user->lastname); ?>" required /> 
                            </span>
                        </li>
                        <li>
                            email
                            <span class="pull-right">
                                <input type="text" class="form-control" name="email" value="<?php echo e($user->email); ?>" required /> 
                            </span>
                        </li>
                        <li>
                            password
                            <span class="pull-right">
                                <input type="text" class="form-control" name="password"  /> 
                            </span>
                        </li>                       
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-link waves-effect">Actualizar</button>
                    <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
        <?php echo e(Form::close()); ?>

    </div>