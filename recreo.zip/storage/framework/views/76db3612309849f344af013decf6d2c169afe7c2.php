 
<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <?php if(Session::has('message')): ?>
        <p class="alert alert-info"><?php echo Session::get('message'); ?></p>
        <?php endif; ?>
        <div class="card">
            <div class="header">
                <h2>
                    Listado de docentes
                    <p class="header-dropdown">
                        <a href="<?php echo e(url('addteacher/teacher')); ?>" class="btn bg-indigo waves-effect">Agregar nuevo docente</a>
                    </p>
                </h2>
            </div>
            <div class="body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Nivel</th>
                                <th>Espacio</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($teacher->name); ?></td>
                                <td><?php echo e($teacher->lastname); ?> </td>
                                <td><?php echo e($teacher->level); ?></td>
                                <td><?php echo e($teacher->space); ?></td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="" class="btn bg-purple waves-effect waves-light" data-toggle="modal" data-target="#teacherModal-<?php echo e($teacher->id); ?>">Ver</a>
                                        <button type="button" class="btn bg-purple waves-effect waves-light" data-toggle="modal" data-target="#teacherEditModal-<?php echo e($teacher->id); ?>">Editar</button>
                                        <button type="button" class="btn bg-red waves-effect waves-light" data-toggle="modal" data-target="#deleteTeacherModal-<?php echo e($teacher->id); ?>">Borrar</button>
                                    </div>
                                </td>
                            </tr>
    <?php echo $__env->make('teachers.modalteachers.profileteacher', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('teachers.modalteachers.editteacher', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('teachers.modalteachers.deleteteacher', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>