<section class="content">
    <div class="container-fluid">
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <strong>¡Antes de continuar!</strong> Por favor verifique los errores para poder guardar al docente.
                </div>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?> <?php if(Session::has('message')): ?>
                <p class="alert alert-success"><?php echo Session::get('message'); ?></p>
                <?php endif; ?> <?php if(Session::has('messageUpdate')): ?>
                <p class="alert alert-danger"><?php echo e(Session::get('messageUpdate')); ?></p>
                <?php endif; ?>
                <div class="card">
                    <div class="header">
                        <h2>
                            Crear nuevo docente
                            <small>Por favor complete todos los campos</small>
                            <p class="header-dropdown">
                                <a href="<?php echo e(url('teachers')); ?>" class="btn bg-indigo waves-effect">Ir al listado de docentes</a>
                            </p>
                        </h2>
                    </div>
                    <?php echo Form::open(['method' => 'POST','route' => ['teachers.store'],'style'=>'display:inline']); ?> 
                    <?php echo e(csrf_field()); ?> 
                    <div class="body">
                        <div class="row clearfix">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" placeholder="Nombre" required />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="lastname" value="<?php echo e(old('lastname')); ?>" placeholder="Apellido" required />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="dni" value="<?php echo e(old('dni')); ?>" placeholder="Dni" required />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="space" value="<?php echo e(old('space')); ?>" placeholder="Espacio" required />
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="Teléfono" required />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="email" min="1" max="9" class="form-control" value="<?php echo e(old('email')); ?>" name="email" placeholder="e-mail" required />
                                    </div>
                                </div>
                                <div class="form-group" required>
                                    <input name="level" type="radio" value="1" id="level1" class="radio-col-purple" />
                                    <label for="level1">Nivel 1</label>
                                    <input name="level" type="radio" id="level2" value="2" class="radio-col-purple" />
                                    <label for="level2">Nivel 2</label>
                                </div>
                                <div class="form-group" required>
                                    <input name="first_time" type="radio" value="SI" id="first_1" class="radio-col-purple" />
                                    <label for="first_1">Participa por primera vez</label>
                                    <input name="first_time" type="radio" id="first_2" value="NO" class="radio-col-purple" />
                                    <label for="first_2">Ya ha participado con anterioridad</label>
                                </div>
                            </div>
                            <button type="submit" class="btn bg-blue btn-block btn-lg waves-effect">Guardar Datos</button>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
</section>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>