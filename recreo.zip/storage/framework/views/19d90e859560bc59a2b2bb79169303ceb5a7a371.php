<div class="modal fade in" id="studentEditModal-<?php echo e($student->id); ?>" tabindex="-1" role="dialog">
    <?php echo Form::model($student, ['method' => 'PATCH','route' => ['students.update', $student->id]]); ?> 
    <?php echo e(csrf_field()); ?>

    <div class="modal-dialog" role="document">
        <div class="modal-content modal-col-indigo">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">Datos del alumno <?php echo e($student->name); ?></h4>
            </div>
            <div class="modal-body">
                <ul class="dashboard-stat-list">
                    <li>
                        Nombre
                        <span class="pull-right">                                
                                    <input type="text" class="form-control" name="name" value="<?php echo e($student->name); ?>" required />
                                </span>
                    </li>
                    <li>
                        Apellido
                        <span class="pull-right">
                            <input type="text" class="form-control" name="lastname" value="<?php echo e($student->lastname); ?>" required /> 
                        </span>
                    </li>
                    <li>
                        DNI
                        <span class="pull-right">
                                    <input type="text" class="form-control" name="dni" value="<?php echo e($student->dni); ?>" required />
                                </span>
                    </li>
                    <li>
                        Fecha Nacimiento
                        <span class="pull-right">
                                    <input type="text" class="form-control" name="birth_date" value="<?php echo e($student->birth_date); ?>" required />
                                </span>
                    </li>
                    <li>
                        Teléfono
                        <span class="pull-right">
                                    <input type="text" class="form-control" name="phone" value="<?php echo e($student->phone); ?>" required />
                                </span>
                    </li>
                    <li>
                        Año Cursado
                        <span class="pull-right">
                                    <input type="number" min="1" max="9"  class="form-control" name="classroom" value="<?php echo e($student->classroom); ?>" required />
                                </span>
                    </li>
                    <li>
                        Nivel
                        <span class="pull-right">
                                        <span class="pull-right"><input type="number" min="1" max="2" class="form-control" name="level" value="<?php echo e($student->level); ?>" required />                                        
                                </span>
                        </span>
                    </li>
                    <li>
                        Paricipa por primera vez 
                            <span class="pull-right">
                                <?php if($student->first_time == 'SI'): ?>
                                    <div class="switch">
                                        <label>NO
                                            <input type="checkbox" name="first_time" value="SI" checked>
                                            <span class="lever switch-col-lime"></span>
                                        </label>
                                        <label>SI</label>
                                    </div>
                                <?php else: ?>
                                    <div class="switch">
                                        <label>NO
                                            <input type="checkbox" name="first_time" value="SI">
                                            <span class="lever switch-col-lime"></span>
                                        </label>
                                        <label>SI</label>
                                    </div>
                                <?php endif; ?>    
                                    </li>  
                            </span>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-link waves-effect">Actualizar</button>
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
    <?php echo e(Form::close()); ?>

</div>