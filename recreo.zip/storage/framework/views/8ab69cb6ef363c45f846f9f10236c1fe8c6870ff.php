<section class="content">
    <div class="container-fluid">
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <strong>¡Antes de continuar!</strong> Por favor antes de continuar complete los datos del
                        colegio.
                    </div>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('message')): ?>
                    <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
                <?php endif; ?>
                <?php if(Session::has('messageUpdate')): ?>
                    <p class="alert alert-danger"><?php echo e(Session::get('messageUpdate')); ?></p>
                <?php endif; ?>
                <div class="card">
                    <div class="header">
                        <h2>
                            Perfíl del colegio
                            <small>Por favor complete todos los campos</small>
                        </h2>
                    </div>

                    <?php echo Form::model($school, ['method' => 'PATCH','route' => ['school.update', $school->schoolId]]); ?>

                    <?php echo e(csrf_field()); ?>

                    <div class="body">
                        <div class="row clearfix">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="name"
                                               value="<?php echo e($school->nameSchool); ?>" placeholder="Nombre completo de la Escuela"
                                               required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line ">
                                        <input type="text" class="form-control" name="city"
                                               value="<?php echo e($school->nameCity); ?>" placeholder="Provincia" disabled
                                               required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="address"
                                               value="<?php echo e($school->address); ?>" placeholder="Dirección Postal" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <?php if($school->postal_code == 0): ?>
                                            <input type="text" class="form-control" name="postal_code"
                                                   placeholder="Código Postal" required/>
                                        <?php else: ?>
                                            <input type="text" class="form-control" name="postal_code"
                                                   value="<?php echo e($school->postal_code); ?>" placeholder="Código Postal"
                                                   required/> <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="phone"
                                               value="<?php echo e($school->phone); ?>" placeholder="Télefono" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <?php if(!isset($locationsUser) ): ?>
                                        <select name="location_id" class="form-control show-tick" required>
                                            <option value="">-- Seleccione la localidad del colegio --</option>
                                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($local->id); ?>"><?php echo e($local->nameLocations); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    <?php else: ?>
                                        <select name="location_id" class="form-control show-tick">
                                            <option value="<?php echo e($locationsUser->id); ?>"><?php echo e($locationsUser->name); ?></option>
                                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($local->id); ?>"><?php echo e($local->nameLocations); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select> <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="director1"
                                               value="<?php echo e($school->director1); ?>" placeholder="Nombre del Director"
                                               required/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">

                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="director2"
                                               value="<?php echo e($school->director2); ?>" placeholder="Nombre del Vice-Director"
                                               required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="email"
                                               value="<?php echo e($school->email); ?>" placeholder="Email del Colegio" disabled
                                               required/>
                                    </div>
                                </div>
                                <br/>
                                <span>Gestión</span>
                                <div class="demo-radio-button">
                                    <?php if($school->type == 'PRIVADA'): ?>
                                        <input name="type" type="radio" value="PRIVADA" id="radio_1"
                                               class="radio-col-purple" checked/>
                                        <label for="radio_1">Gestión Privada</label>
                                        <input name="type" type="radio" value="PUBLICA" id="radio_2"
                                               class="radio-col-purple"/>
                                        <label for="radio_2">Gestión Publica</label> <?php else: ?>
                                        <input name="type" type="radio" value="PRIVADA" id="radio_1"
                                               class="radio-col-purple"/>
                                        <label for="radio_1">Gestión Privada</label>
                                        <input name="type" type="radio" value="PUBLICA" id="radio_2"
                                               class="radio-col-purple" checked/>
                                        <label for="radio_2">Gestión Publica</label> <?php endif; ?>
                                </div>
                                <br/><br/>
                                <span>Pariticipación del colegio</span>
                                <div class="demo-radio-button">
                                    <?php if($school->first_time == 'SI'): ?>
                                        <input name="first_time" type="radio" value="SI" id="first_1"
                                               class="radio-col-purple" checked/>
                                        <label for="first_1">Participo por primera vez</label>
                                        <input name="first_time" type="radio" id="first_2" value="NO"
                                               class="radio-col-purple"/>
                                        <label for="first_2">Ya ha participado con anterioridad</label> <?php else: ?>
                                        <input name="first_time" type="radio" value="SI" id="first_1"
                                               class="radio-col-purple"/>
                                        <label for="first_1">Participo por primera vez</label>
                                        <input name="first_time" type="radio" id="first_2" value="NO"
                                               class="radio-col-purple" checked/>
                                        <label for="first_2">Ya ha participado con anterioridad</label> <?php endif; ?>
                                </div>
                                <br/><br/>
                                <span>Postularse para ser Sede</span>
                                <div class="demo-radio-button">
                                    <?php if($school->sede == 'SI'): ?>
                                        <input name="sede" type="radio" value="SI" id="sede"
                                               class="radio-col-purple" checked/>
                                        <label for="sede">Si</label>
                                        <input name="sede" type="radio" id="sede2" value="NO"
                                               class="radio-col-purple"/>
                                        <label for="sede2">No</label>
                                    <?php else: ?>
                                        <input name="sede" type="radio" value="SI" id="sede"
                                               class="radio-col-purple"/>
                                        <label for="sede">Si</label>
                                        <input name="sede" type="radio" id="sede2" value="NO"
                                               class="radio-col-purple" checked/>
                                        <label for="sede2">No</label>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn bg-blue btn-block btn-lg waves-effect">Guardar Datos</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
</section>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>