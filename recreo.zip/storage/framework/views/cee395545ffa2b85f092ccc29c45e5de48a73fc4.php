<section class="content">
    <div class="container-fluid">
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <strong>¡Antes de continuar!</strong> Por favor verifique los errores para poder guardar al
                        alumno.
                    </div>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?> <?php if(Session::has('message')): ?>
                    <p class="alert alert-success"><?php echo Session::get('message'); ?></p>
                <?php endif; ?> <?php if(Session::has('messageUpdate')): ?>
                    <p class="alert alert-danger"><?php echo e(Session::get('messageUpdate')); ?></p>
                <?php endif; ?>
                <div class="card">
                    <div class="header">
                        <h2>
                            Crear nuevo Alumno
                            <small>Por favor complete todos los campos</small>
                            <p class="header-dropdown">
                                <a href="<?php echo e(url('admin/adminstudent')); ?>" class="btn bg-indigo waves-effect">Ir al listado de
                                    alumnos</a>
                            </p>
                        </h2>
                    </div>
                    <?php echo Form::model($student, ['method' => 'PATCH','route' => ['adminstudent.update', $student->id]]); ?>

                    <?php echo e(csrf_field()); ?>

                    <div class="body">
                        <div class="row clearfix">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="name" value="<?php echo e($student->name); ?>"
                                               placeholder="Nombre" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="lastname"
                                               value="<?php echo e($student->lastname); ?>" placeholder="Apellido" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="dni" value="<?php echo e($student->dni); ?>"
                                               placeholder="Dni" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="date" class="form-control" name="birth_date"
                                               value="<?php echo e($student->birth_date); ?>" placeholder="Fecha de nacimiento"
                                               required/>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="number" class="form-control" name="first_note"
                                               value="<?php echo e($student->first_note); ?>" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="number" class="form-control" name="second_note"
                                               value="<?php echo e($student->second_note); ?>" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="total_note"
                                               value="<?php echo e($student->total_note); ?>" disabled />
                                    </div>
                                </div>

                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="phone"
                                               value="<?php echo e($student->phone); ?>" placeholder="Teléfono de contacto"
                                               required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-line">
                                        <select name="classroom"
                                                class="form-control show-tick" required>
                                            <option value="<?php echo e($student->classroom); ?>"><?php echo e($student->classroom); ?></option>
                                            <option value="">-- Seleccione el nivel del alumno --</option>
                                            <option value="4 primaria">4to primaria</option>
                                            <option value="5 primaria">5to primaria</option>
                                            <option value="6 primaria">6to primaria</option>
                                            <option value="7 primaria">7mo primaria</option>
                                            <option value="8 primaria">8vo primaria</option>
                                            <option value="9 primaria">9no primaria</option>
                                            <option value="1 secundaria">1ro secundario</option>
                                            <option value="2 secundaria">2do secundario</option>
                                            <option value="3 secundaria">3ro secundario</option>
                                            <option value="4 secundaria">4to secundario</option>
                                            <option value="5 secundaria">5to secundario</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group" required>
                                    <?php if($student->level == 1): ?>
                                        <input name="level" type="radio" value="1" id="level1" class="radio-col-purple"
                                               checked/>
                                        <label for="level1">Nivel 1</label>
                                        <input name="level" type="radio" id="level2" value="2"
                                               class="radio-col-purple"/>
                                        <label for="level2">Nivel 2</label>
                                    <?php else: ?>
                                        <input name="level" type="radio" value="1" id="level1"
                                               class="radio-col-purple"/>
                                        <label for="level1">Nivel 1</label>
                                        <input name="level" type="radio" id="level2" value="2"
                                               class="radio-col-purple" checked/>
                                        <label for="level2">Nivel 2</label>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group" required>
                                    <?php if($student->first_time == 'SI'): ?>
                                        <input name="first_time" type="radio" value="SI" id="first_1"
                                               class="radio-col-purple" checked />
                                        <label for="first_1">Participa por primera vez</label>
                                        <input name="first_time" type="radio" id="first_2" value="NO"
                                               class="radio-col-purple"/>
                                        <label for="first_2">Ya ha participado con anterioridad</label>
                                    <?php else: ?>
                                        <input name="first_time" type="radio" value="SI" id="first_1"
                                               class="radio-col-purple"/>
                                        <label for="first_1">Participa por primera vez</label>
                                        <input name="first_time" type="radio" id="first_2" value="NO"
                                               class="radio-col-purple" checked/>
                                        <label for="first_2">Ya ha participado con anterioridad</label>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <button type="submit" class="btn bg-blue btn-block btn-lg waves-effect">Guardar Datos
                            </button>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>