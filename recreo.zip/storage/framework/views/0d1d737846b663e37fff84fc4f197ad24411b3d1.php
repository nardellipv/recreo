 
<?php $__env->startSection('content'); ?>
<form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="card">
        <div class="body">
            <div class="panel-heading">Reestablesca su contraseña</div>
            <div class="panel-body">
                <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
                <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('password.email')); ?>" aria-label="<?php echo e(__('Reset Password')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="input-group">
                        <span class="input-group-addon">
                                            <i class="material-icons">mail</i>
                                        </span>
                        <div class="form-line <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <input id="email" type="email" class="form-control" placeholder="Ingrese su mail" name="email" value="<?php echo e(old('email')); ?>"
                                required autofocus> <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                                    <strong><?php echo e($errors->first('email')); ?></strong>
                            </span> <?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">                                                <button type="submit" class="btn btn-primary btn-lg btn-block">
                                <?php echo e(__('Enviar mi contraseña')); ?>

                            </button></div>
                        <div class="col-sm-6"><a href="<?php echo e(route('login')); ?>" class="btn btn-block btn-lg bg-blue waves-effect" type="submit">Volver al inicio</a></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>