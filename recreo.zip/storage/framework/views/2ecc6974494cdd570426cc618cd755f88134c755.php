<div class="modal fade in" id="studentAddNoteModal-<?php echo e($student->id); ?>" tabindex="-1" role="dialog">
    <?php echo Form::model($student, ['method' => 'PATCH','route' => ['students.update', $student->id]]); ?> 
    <?php echo e(csrf_field()); ?>

    <div class="modal-dialog" role="document">
        <div class="modal-content modal-col-indigo">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">Datos del alumno <?php echo e($student->name); ?></h4>
            </div>
            <div class="modal-body">
                <ul class="dashboard-stat-list">
                    <li>
                        Nombre
                        <span class="pull-right"><p><?php echo e($student->name); ?></p>                                
                    </li>
                    <li>
                        Apellido
                        <span class="pull-right">
                            <span class="pull-right"><p><?php echo e($student->lastname); ?></p>                                
                    </li>                   
                    <li>
                        Nivel
                        <span class="pull-right">
                            <span class="pull-right"><p><?php echo e($student->level); ?></p>                                
                    </li>
                    <li>
                        Primera Nota (expresada en %)
                        <span class="pull-right">
                            <span class="pull-right">
                                <?php if($student->first_note): ?>
                                    <p><?php echo e($student->first_note); ?> %</p>
                                    <?php else: ?>
                                    <input type="number" min="0" max="100" class="form-control" name="first_note" value="<?php echo e($student->first_note); ?>" />
                                    <?php endif; ?>
                            </span>
                    </li>
                    <?php if($student->level == 2): ?>
                    <li>
                        Segunda Nota
                        <span class="pull-right">
                            <span class="pull-right">
                                    <?php if($student->second_note): ?>
                                    <p><?php echo e($student->second_note); ?> %</p>
                                    <?php else: ?>
                                    <input type="number" min="0" max="100" class="form-control" name="second_note" value="<?php echo e($student->second_note); ?>" />
                                    <?php endif; ?>
                            </span>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-link waves-effect">Actualizar</button>
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
    <?php echo e(Form::close()); ?>

</div>