 
<?php $__env->startSection('content'); ?>
<form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="signup-box">
        <div class="card">
            <div class="body">
                <div class="msg">Registro de nuevo usuario</div>
                <div class="input-group">
                    <span class="input-group-addon">
                            <i class="material-icons">person</i>
                        </span>
                    <div class="form-line <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <input id="name" type="text" class="form-control" name="name" placeholder="ingrese su nombre" value="<?php echo e(old('name')); ?>" required
                            autofocus> <?php if($errors->has('name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span> <?php endif; ?>
                    </div>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                            <i class="material-icons">person</i>
                        </span>
                    <div class="form-line <?php echo e($errors->has('lastname') ? ' has-error' : ''); ?>">
                        <input id="name" type="text" class="form-control" name="lastname" placeholder="ingrese su apellido" value="<?php echo e(old('lastname')); ?>" required
                            autofocus> <?php if($errors->has('lastname')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('lastname')); ?></strong>
                        </span> <?php endif; ?>
                    </div>
                </div>
                <div class="input-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <span class="input-group-addon">
                            <i class="material-icons">email</i>
                        </span>
                    <div class="form-line">
                        <input id="email" type="email" class="form-control" placeholder="ingrese su mail" name="email" value="<?php echo e(old('email')); ?>"
                            required> <?php if($errors->has('email')): ?>
                        <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span> <?php endif; ?>
                    </div>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                            <i class="material-icons">lock</i>
                        </span>
                    <div class="form-line <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <input id="password" type="password" placeholder="Ingrese su contraseña" class="form-control" name="password" required>                        <?php if($errors->has('password')): ?>
                        <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span> <?php endif; ?>
                    </div>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                            <i class="material-icons">lock</i>
                        </span>
                    <div class="form-line">
                        <input id="password-confirm" type="password" placeholder="Confirme su contraseña" class="form-control" name="password_confirmation"
                            required>
                    </div>
                </div>
                <button class="btn btn-block btn-lg bg-pink waves-effect" type="submit">SIGN UP</button>
                <div class="m-t-25 m-b--5 align-center">
                    <a href="<?php echo e(route('login')); ?>">Volver al login</a>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>