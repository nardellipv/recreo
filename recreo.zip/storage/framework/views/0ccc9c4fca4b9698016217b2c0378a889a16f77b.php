<div class="modal fade in" id="teacherModal-<?php echo e($teacher->id); ?>" tabindex="-1" role="dialog" ">
        <div class="modal-dialog " role="document ">
            <div class="modal-content modal-col-indigo ">
                <div class="modal-header ">
                    <h4 class="modal-title " id="defaultModalLabel ">Datos del alumno <?php echo e($teacher->name); ?></h4>
                </div>
                <div class="modal-body ">
                    
                    <ul class="dashboard-stat-list ">
                            <li>
                                Nombre
                                <span class="pull-right "><b><?php echo e($teacher->name); ?></b>
                            </li>
                            <li>
                                Apellido
                                <span class="pull-right "><b><?php echo e($teacher->lastname); ?></b> 
                            </li>
                            <li>
                                DNI
                                <span class="pull-right "><b><?php echo e($teacher->dni); ?></b> 
                            </li>
                            <li>
                                Espacio
                                <span class="pull-right "><b><?php echo e($teacher->space); ?></b> 
                            </li>
                            <li>
                                Teléfono
                                <span class="pull-right "><b><?php echo e($teacher->phone); ?></b> 
                            </li>
                            <li>
                                EMail
                                <span class="pull-right "><b><?php echo e($teacher->email); ?></b> 
                            </li>
                            <li>
                                Nivel
                                <span class="pull-right "><b><?php echo e($teacher->level); ?></b> 
                            </li>
                            <li>
                                Paricipa por primera vez
                                <span class="pull-right "><b><?php echo e($teacher->first_time); ?></b> 
                            </li>
                        </ul>
                </div>
                <div class="modal-footer">            
                    <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>