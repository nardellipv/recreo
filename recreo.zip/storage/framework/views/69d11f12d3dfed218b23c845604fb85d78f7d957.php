<div class="tour-step 8 card">
    <div class="header">
        <h2>
            Área de información y descargas
            <small>Información y descarga de documentación importante sobre la olimpiada</small>
        </h2>
    </div>

    <div class="body">
        <div class="row clearfix">
            <div class="row">
                <div class="col-xs-6">
                    <?php if(Auth::user()->nivelI): ?>
                        <div class="card">
                            <div class="header bg-light-blue">
                                <h2>
                                    Evaluación Nivel 1
                                    <small>Por favor descargue la evaluación</small>
                                </h2>
                            </div>
                            <div class="body">
                                <p>Descargue las evaluaciones de los siguientes links.</p>
                                <a href="https://recreo.mikant.com/download/examen/INTERCOLEGIAL%20NIVEL%20I%202018.pdf" target="_blank">INTERCOLEGIAL NIVEL I 2018</a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-xs-6">
                    <?php if(Auth::user()->nivelII): ?>
                        <div class="card">
                            <div class="header bg-light-blue">
                                <h2>
                                    Evaluación Nivel 2
                                    <small>Por favor descargue la evaluación</small>
                                </h2>
                            </div>
                            <div class="body">
                                <p>Descargue las evaluaciones de los siguientes links.</p>
                                <a href="https://recreo.mikant.com/download/examen/OPCION%20M%C3%9ALTIPLE%20INTERCOLEGIAL%20NIVEL%20II%202018.pdf" target="_blank" target="_blank">OPCION MÚLTIPLE INTERCOLEGIAL NIVEL II 2018</a><p>
                                <a href="https://recreo.mikant.com/download/examen/PRUEBA%20EXPERIMENTAL%20INTERCOLEGIAL%20NIVEL%20II%202018.pdf" target="_blank">PRUEBA EXPERIMENTAL INTERCOLEGIAL NIVEL II 2018</a><p>
                                <a href="https://recreo.mikant.com/download/examen/RESOLUCION%20DE%20PROBLEMA%20NIVEL%20II%20INTERCOLEGIAL%202018.pdf" target="_blank">RESOLUCION DE PROBLEMA NIVEL II INTERCOLEGIAL 2018</a><p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="card">
                        <div class="header bg-light-blue">
                            <h2>
                                Notas de los examenes
                                <small>Fechas disponibles</small>
                            </h2>
                        </div>
                        <div class="body">
                            Se avisará con anticipación mediante un mensaje en este mismo sitio cuando se encuentre
                            habilitada la opción
                            para poder ingresar las notas de los alumnos.
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="card">
                        <div class="header bg-light-blue">
                            <h2>
                                REGLAMENTO GENERAL 2018
                                <small>Descarga</small>
                            </h2>
                        </div>
                        <div class="body">
                            Descarge el reglamento desde <a href="<?php echo e(url('download/Reglamento2018.pdf')); ?>"
                                                            target="_blank">aquí</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="card">
                        <div class="header bg-light-blue">
                            <h2>
                                Subir el exámen
                                <small>Exámen modelo</small>
                            </h2>
                        </div>
                        <div class="body">
                            Por favor suba el exámen modelo que se tomó a los alumnos en formato <b>PDF</b>.
                            Para subirlo haga click en el siguiente link <a href="<?php echo e(url('showUploadFile')); ?>">Subir
                                PDF</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>