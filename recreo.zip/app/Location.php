<?php

namespace recreo;

use Illuminate\Database\Eloquent\Model;

class Location extends Model
{
    //
}
